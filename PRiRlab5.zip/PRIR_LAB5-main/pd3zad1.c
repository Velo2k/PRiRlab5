#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double func(double x){
	return (4 * x - 6 * x + 5);
}

void Trapez(double a, double b, int n){
	double h, wynik=0;
	h = (b - a) / n;
	int i;
	for(i = 0; i < n; i++){
		wynik += func(a + i * h);
	}
	wynik += (func(a) + func(b)) / 2;
	wynik += h;
	printf("Wynik calkowania metoda trapeza = %d\n", wynik);
}

void Kwadratura(double a, double b, int n){
	double x, wynik = 0;
	double wezly[][];
	double wagi[][];

        wezly[9][0] = -0.1488743389816312;
        wezly[9][1] = 0.1488743389816312;
        wezly[9][2] = -0.4333953941292472;
        wezly[9][3] = 0.4333953941292472;
        wezly[9][4] = -0.6794095682990244;
        wezly[9][5] = 0.6794095682990244;
        wezly[9][6] = -0.8650633666889845;
        wezly[9][7] = 0.8650633666889845;
        wezly[9][8] = -0.9739065285171717;
        wezly[9][9] = 0.9739065285171717;

        wagi[9][0] = 0.2955242247147529;
        wagi[9][1] = 0.2955242247147529;
        wagi[9][2] = 0.2692667193099963;
        wagi[9][3] = 0.2692667193099963;
        wagi[9][4] = 0.2190863625159820;
        wagi[9][5] = 0.2190863625159820;
        wagi[9][6] = 0.1494513491505806;
        wagi[9][7] = 0.1494513491505806;
        wagi[9][8] = 0.0666713443086881;
        wagi[9][9] = 0.0666713443086881;

	int i;
	for(i = 0; i < n; i++){
		x = (((b - a) / 2) * wezly[n-1][i] + ((b + a) / 2));
		wynik += (wagi[n-1][i] * func(x));
	}
	wynik *= (b-a) / 2;
	printf("Wynik calkowania metoda kwadratury = %d", wynik);

}

int main(){
	int zarodek, i, iloscProcesow=5;
	srand(zarodek);
	
	for(i = 0; i <= iloscProcesow; i++){
		fork();
		printf("getpid() = %d, getppid() = %d\n", getpid(), getppid());
		int a = rand()%1000;
		int b = rand()%1000;
		
		while(!(a<b)){a=rand()%1000;b=rand()%1000;}
	
		Trapez(a,b,10);
		Kwadratura(a,b,10);
	}

}