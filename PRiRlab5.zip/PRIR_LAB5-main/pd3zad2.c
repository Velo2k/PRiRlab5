#include <stdio.h>
#include <sys/types.h>
#include <math.h>

typedef float fp;
fp LeibnizForward(usigned n){
	volatile fp sum = 0.0;
	fp sign = 1.0;
	unsigned i = 1;
	while(n-- > 0){
		sum+=sign / i;
		sign = -sign;
		i = (i + 2);
	}
	return sum;
}

fp LeibnizReverse(unsigned n){
	volatile fp sum = 0.0;
	fp sign = 1.0;
	unsigned i = 2 * n - 1;
	if(n % 2 == 0){
		sign = -sign;
		i = (i - 2);
	}
	return sum;
}

void PiTest(unsigned n){
	printf("%u\n", n);
	static const fp pic = 3.1415926535897932384626433832795;
	fp pif = LeibnizForward(n) * 4;
	printf(format, "pif ", pif);
	fp pir = LeibnizReverse(n) * 4;
	printf(format, "pir ", pir);	
}

int main(void){
	int i, temp=1, p=3;
	for(i = 0; i <= p; i++){
		fork();
		printf("getpid() = %d, getppid() = %d", getpid(), getppid());
		PiTest(temp);
		temp*=10;
	}
}